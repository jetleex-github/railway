package com.eaosoft.railway.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author zzs
 * @since 2023-03-16
 */
@RestController
@RequestMapping("/railway/logOperate")
public class LogOperateController {

}
