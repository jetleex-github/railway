package com.eaosoft.railway.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.eaosoft.railway.entity.User;
import com.eaosoft.railway.service.IUserService;
import com.eaosoft.railway.utils.MD5Utils;
import com.eaosoft.railway.utils.ReqValue;
import com.eaosoft.railway.utils.RespValue;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author zzs
 * @since 2023-03-17
 */
@RestController
@RequestMapping("/railway/user")
public class UserController {

    @Autowired
    private IUserService userService;


    /**
     * login
     * @param reqValue
     * @return
     */
    @RequestMapping("/login.do")
    public RespValue login(@RequestBody ReqValue reqValue){
        Object requestDatas = reqValue.getRequestDatas();
        JSONObject jsonObject = JSONObject.parseObject(JSON.toJSONString(requestDatas));
        String username = jsonObject.getString("username");
        String password = jsonObject.getString("password");
        String s = MD5Utils.md5(password);
        User user = userService.login(username, s);
        //String token = userService.getToken(username,password);
        //RespValue respValue = new RespValue();
        //respValue.setData();
        if (user != null){
            return new RespValue(200,"success",user);
        }
        return new RespValue(500,"The account or password is incorrect",null);
    }

    /**
     * addUser
     * @param reqValue
     * @return
     */
    @RequestMapping("/addUser.do")
    public RespValue addUser(@RequestBody ReqValue reqValue){
        Object requestDatas = reqValue.getRequestDatas();
        JSONObject jsonObject = JSONObject.parseObject(JSON.toJSONString(requestDatas));
        String username = jsonObject.getString("username");
        User user = userService.selectByUsername(username);
        if (user != null){
            return new RespValue(500,"The username already exists",null);
        }
        User user1 = new User();
        user1.setUsername(jsonObject.getString("username"));
        // Encrypt the password with MD5
        String s = MD5Utils.md5(jsonObject.getString("password"));
        user1.setPassword(s);
        user1.setCaption(jsonObject.getString("caption"));
        user1.setGender(jsonObject.getInteger("gender"));
        user1.setSerialNo(jsonObject.getString("serialNo"));
        user1.setAge(jsonObject.getInteger("age"));
        user1.setPhone(jsonObject.getString("phone"));
        user1.setAddress(jsonObject.getString("address"));
        user1.setCreateTime(LocalDateTime.now());
        user1.setUpdateTime(LocalDateTime.now());
        user1.setStation(jsonObject.getString("station"));
        int i = userService.addUser(user1);

        if (i != 0){
            return new RespValue(200,"success",user1);
        }
        return new RespValue(500,"Adding a user fails",null);
    }


    /**
     * 根据用户名查询用户是否存在
     * @param reqValue
     * @return
     */
    @RequestMapping("/findByUsername.do")
    public RespValue findByUsername(@RequestBody ReqValue reqValue){
        Object requestDatas = reqValue.getRequestDatas();
        JSONObject jsonObject = JSONObject.parseObject(JSON.toJSONString(requestDatas));
        String username = jsonObject.getString("username");
        User user = userService.selectByUsername(username);

        return new RespValue(200,"success",user);


    }
}
