package com.eaosoft.railway.service.impl;

import com.eaosoft.railway.entity.Role;
import com.eaosoft.railway.mapper.RoleMapper;
import com.eaosoft.railway.service.IRoleService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author zzs
 * @since 2023-03-16
 */
@Service
public class RoleServiceImpl extends ServiceImpl<RoleMapper, Role> implements IRoleService {

}
