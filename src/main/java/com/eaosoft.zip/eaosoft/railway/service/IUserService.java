package com.eaosoft.railway.service;

import com.eaosoft.railway.entity.User;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author zzs
 * @since 2023-03-17
 */
public interface IUserService extends IService<User> {





    User login(String username, String password);

    User selectByUsername(String username);



    int addUser(User user);

   //  String getToken(User user);
}
