package com.eaosoft.railway.service.impl;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.eaosoft.railway.entity.User;
import com.eaosoft.railway.mapper.UserMapper;
import com.eaosoft.railway.service.IUserService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author zzs
 * @since 2023-03-17
 */
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements IUserService {

    @Autowired
    private UserMapper userMapper;

    /**
     *
     * @param username
     * @param password
     * @return
     */
    @Override
    public User login(String username, String password) {
        User user  =  userMapper.selectByUsernameAndPassword(username,password);
        return user;
    }

    /**
     * Check whether the username exists
     * @param username
     * @return
     */
    @Override
    public User selectByUsername(String username) {
        User user= userMapper.selectByUsername(username);
        return user;
    }

    /**
     * addUser
     * @param user
     * @return
     */
    @Override
    public int addUser(User user) {
        int insert = userMapper.insert(user);
        return insert;
    }

  /*  @Override
    public String getToken(User user) {
        Date start = new Date();
        long currentTime = System.currentTimeMillis() + (60*8)* 60 * 1000;
        Date end = new Date(currentTime);
        String token = "";

        Algorithm algorithm = Algorithm.HMAC256(user.getPassword());
        token = JWT.create()
                .withAudience(String.valueOf(user.getUid()))
                .withIssuedAt(start).withExpiresAt(end)
                .sign(algorithm);
        authTokenService.deleteToken(token);
        //save
        authTokenService.setToken(token,currentTime);
        return token;
    }*/


}
