package com.eaosoft.railway.service;

import com.eaosoft.railway.entity.LogOperate;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author zzs
 * @since 2023-03-16
 */
public interface ILogOperateService extends IService<LogOperate> {

}
